package com.icia.zboard3.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.icia.zboard3.entity.Board;
import com.icia.zboard3.service.BoardService;

@WebServlet("/board")
public class ReadServlet extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		long bno = Long.parseLong(request.getParameter("bno"));
		Board board = BoardService.read(bno);
		
		response.setContentType("application/json");
		response.setCharacterEncoding("utf-8");
		String json = new ObjectMapper().writeValueAsString(board);
		PrintWriter out = response.getWriter();
		out.print(json);
	}
}
