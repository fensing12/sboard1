package com.icia.zboard3.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.icia.zboard3.entity.Page;
import com.icia.zboard3.service.BoardService;

@WebServlet("/board/all")
public class ListServlet extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int pageno = Integer.parseInt(request.getParameter("pageno"));
		Page page = BoardService.list(pageno);
		
		response.setContentType("application/json");
		response.setCharacterEncoding("utf-8");
		String json = new ObjectMapper().writeValueAsString(page);
		PrintWriter out = response.getWriter();
		out.print(json);
	}
}
