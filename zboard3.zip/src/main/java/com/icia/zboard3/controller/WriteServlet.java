package com.icia.zboard3.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.icia.zboard3.entity.Board;
import com.icia.zboard3.service.BoardService;

// 이 서블릿은 파일 업로드를 할 거다
@MultipartConfig
@WebServlet("/board/new")
public class WriteServlet extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String writer = request.getParameter("writer");
		String title = request.getParameter("title");
		String content = request.getParameter("content");
		Part attachment = request.getPart("attachment");
		
		Board board = new Board(title, content, writer);
		Board result = BoardService.write(board, attachment);
		String json = new ObjectMapper().writeValueAsString(result);
		response.setContentType("application/json");
		response.setCharacterEncoding("utf-8");
		response.getWriter().print(json);
		
	}
}






