package com.icia.zboard3.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.Part;

import com.icia.zboard3.entity.Board;
import com.icia.zboard3.entity.Page;

public class BoardService {
	static String attachmentFolder = "c:/upload/";
	static String attachmentUrl = "http://localhost:8081/images/";
	static List<Board> list = new ArrayList<>();
	static long bno = 1;
	static int pagesize = 10;
	
	static {
		for(int i=0; i<123; i++) {
			BoardService.write(new Board(i+"", i+"", i+""), null);
		}
	}
	
	public static Board write(Board board, Part a) {
		// <input type='file' name='attachment'가 있고 업로드했다면
		// attachment는 널이 될 수도 있고 비어있을 수도 있다
		// 이런 객체는 반드시 널 체크부터
		if(a!=null && !a.getSubmittedFileName().equals("")) {
			String name = System.currentTimeMillis()+"-"
					+ a.getSubmittedFileName();
			try {
				// 파일이름이 겹치면 오류가 발생 -> 겹치지 않게 하자
				// 겹치면 바꾸는 건 어렵다 -> 미리 바꾸자
				a.write(attachmentFolder + name);
			} catch (IOException e) {
				e.printStackTrace();
			}
			board.setAttachment(attachmentUrl+name);
		}
		// 어제는 1, 2, 3, 4....순서로 들어가서 거꾸로 뒤집어 출력했다
		// add할때 저장 위치를 0번으로 지정해서 저장하면 뒤집을 필요가 없다
		list.add(0, board.setBno(bno++));
		return board;
	}
	
	public static Page list(int pageno) {
		// 13 12 11.....3 2 1
		// pageno 1	0~9, 2 10~19
		int start = (pageno-1) * pagesize;
		int end = start + pagesize - 1;
		List<Board> result = new ArrayList<>();
		for(int i=start; i<=end; i++)
			result.add(list.get(i));
		return new Page(pageno, pagesize, list.size(), result);
	}
	
	public static Board read(long bno) {
		// 향상된 for, of반복문 : 원소를 하나씩 꺼내서 작업. 원본 변경 불가능
		// for문 : arraylist에서 직접 작업
		for(int i=0; i<list.size(); i++) {
			if(list.get(i).getBno()==bno) {
				list.get(i).setReadcnt(list.get(i).getReadcnt()+1);
				return list.get(i);
			}
		}
		return null;
	}
	
	public static Board update(Board board) {
		for(int i=0; i<list.size(); i++) {
			if(list.get(i).getBno()==board.getBno()) {
				list.get(i).setTitle(board.getTitle());
				list.get(i).setContent(board.getContent());
				return list.get(i);
			}
		}
		return null;
	}
	
	public static void delete(long bno) {
		for(int i=0; i<list.size(); i++) {
			if(list.get(i).getBno()==bno)
				list.remove(i);
		}
	}
}



















