package com.icia.zboard3.entity;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Page {
	private int pageno;
	private int pagesize;
	private int totalcount;
	private List<Board> boardList;
}
