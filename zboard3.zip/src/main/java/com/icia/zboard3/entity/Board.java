package com.icia.zboard3.entity;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Data
@AllArgsConstructor
@Builder
@Accessors(chain=true)
public class Board {
	public Board(String title, String content, String writer) {
		this.title = title;
		this.content = content;
		this.writer = writer;
	}
	private Long bno;
	private String title;
	private String content;
	private String writer;
	private Integer readcnt = 0;
	@JsonFormat(pattern="yyyy년 MM월 dd일 hh시 mm분 ss초")
	private Date writetime = new Date();
	
	// 첨부파일의 경로를 저장할 문자열
	// http://localhost:8081/images/이미지이름
	private String attachment;
}




