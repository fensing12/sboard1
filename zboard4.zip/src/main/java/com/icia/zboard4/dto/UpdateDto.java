package com.icia.zboard4.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class UpdateDto {
	private String title;
	private String content;
	private Integer bno;
	private String password;
}







