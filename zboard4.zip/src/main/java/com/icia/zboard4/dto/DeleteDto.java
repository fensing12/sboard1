package com.icia.zboard4.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class DeleteDto {
	private Integer bno;
	private String password;
}







