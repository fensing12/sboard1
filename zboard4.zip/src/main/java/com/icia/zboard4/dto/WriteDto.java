package com.icia.zboard4.dto;

import java.util.Date;

import com.icia.zboard4.entity.Board;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class WriteDto {
	private String title;
	private String content;
	private String writer;
	private String password;
	public Board toEntity() {
		return Board.builder().title(title).content(content)
			.writer(writer).password(password).readCnt(0)
			.writeDate(new Date()).build();
	}
}







