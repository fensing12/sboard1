package com.icia.zboard4.service;

import java.util.ArrayList;
import java.util.List;

import com.icia.zboard4.dto.DeleteDto;
import com.icia.zboard4.dto.UpdateDto;
import com.icia.zboard4.dto.WriteDto;
import com.icia.zboard4.entity.Board;

public class BoardService {
	private static int bno = 1;
	private static List<Board> list = new ArrayList<>();
	
	public static Board write(WriteDto dto) {
		Board board = dto.toEntity();
		board.addBno(bno++);
		list.add(board);
		return board;
	}
	
	public static Board read(Integer bno) {
		for(int i=0; i<list.size(); i++) {
			if(list.get(i).getBno()==bno) {
				list.get(i).increaseReadCnt();
				return list.get(i);
			}
		}
		return null;
	}
	
	public static List<Board> list() {
		return list;
	}
	
	public static Board update(UpdateDto dto) {
		for(int i=0;i<list.size();i++) {
			if(list.get(i).getBno()==dto.getBno()) {
				list.get(i).update(dto);
				return list.get(i);
			}
		}
		return null;
	}
	
	public static int delete(DeleteDto dto) {
		for(int i=0;i<list.size();i++) {
			if(list.get(i).getBno()==dto.getBno() && 
					list.get(i).getPassword().equals(dto.getPassword())) {
				// 글번호로 글을 찾아서 비밀번호가 일치하면 list에서 삭제 후 1리턴
				list.remove(i);
				return 1;
			}
		}
		// 글을 못 찾았으면 0리턴
		return 0;
	}
}
