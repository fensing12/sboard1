package com.icia.zboard4.entity;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.icia.zboard4.dto.UpdateDto;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class Board {
	private Integer bno;			
	private String title;		
	private String content;		
	private String writer;	
	@JsonIgnore
	private String password;
	private Date writeDate;		
	private Integer readCnt;
	
	public void addBno(Integer bno) {
		this.bno = bno;
	}
	
	public void update(UpdateDto dto) {
		if(this.password.equals(dto.getPassword())==false)
			return;
		this.title = dto.getTitle();
		this.content = dto.getContent();
	}
	
	public void increaseReadCnt() {
		this.readCnt++;
	}
}

