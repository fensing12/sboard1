package com.icia.zbaord5.service;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import com.icia.zboard5.dto.WriteDto;
import com.icia.zboard5.entity.Board;

public class BoardServiceTest {
	BoardService service = BoardService.getInstance();
	
	//@Test
	public void writeTest() {
		WriteDto dto = new WriteDto("1번글", "1번글", "spring", null);
		Board board = service.write(dto);
		assertEquals(1, board.getBno());
	}
	
	@Test
	public void listTest() {
		for(int i=0; i<13; i++) {
			service.write(new WriteDto(i+"", i+"번째 글", "spring", null));
		}
		assertEquals(3, service.list(2).size());
	}
	
	//@Test
	public void readTest() {
		for(int i=0; i<13; i++) {
			service.write(new WriteDto(i+"", i+"번째 글", "spring", null));
		}
		assertEquals(true, service.read(3).isPresent());
		assertEquals(true, service.read(111).isEmpty());
	}
}





