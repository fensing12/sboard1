package com.icia.zbaord5.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Vector;
import java.util.stream.Collectors;

import javax.servlet.http.Part;

import com.icia.zboard5.dto.WriteDto;
import com.icia.zboard5.entity.Board;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access=AccessLevel.PRIVATE)
public class BoardService {
	// java.util.Collection 인터페이스의 자식들
	// java.util.List 인터페이스 : 순서있고 중복가능한 집합
	// java.util.Set 인터페이스 : 순서없고 중복불가능한 집합 
	// java.util.Map : 정보를 key, value로 표현
	private List<Board> list = new Vector<>();
	private int bno = 1;
	private final Integer pagesize = 10;
	private final String uploadFolder = "c:/upload/";
	private final String uploadUrl = "http://localhost:8081/images/";
	
	// Singleton 패턴 적용-static과 마찬가지역할. 보통 스태틱 대신 싱글톤을 사용
	// 1. 외부에서 new 금지
	// 2. 자신의 static 필드 생성
	// 3. 빌려가는 메소드 getInstance 추가
	private static BoardService service = new BoardService();
	public static BoardService getInstance() {
		return service;
	}
	
	public Board write(WriteDto dto) {
		Board board = dto.toEntity();
		Part a = dto.getAttachment();
		// 파일 업로드를 했는 지 확인하자 - null체크, 비어있는 체크
		// 파일이 null이 아니고 파일명이 존재한다면
		if(a!=null && !a.getSubmittedFileName().equals("")) {
			String name = System.currentTimeMillis()+"-"
					+ a.getSubmittedFileName();
			try {
				a.write(uploadFolder +  name);
			} catch (IOException e) {
				e.printStackTrace();
			}
			board.init(uploadUrl, name, bno++);
		} else
			board.init(bno++);
		list.add(0, board);
		return board;
	}
	
	public Optional<Board> read(Integer bno) {
		// Predicate : (객체)->{ return 참거짓; }  
		return list.stream().filter(b->b.getBno()==bno).findFirst();
	}
	
	public List<Board> list(Integer pageno) {
		// 글이 13 12 11 10 9 8 7 6 5 4 3 2 1 
		// pageno 1. list.get(0) ~ list.get(9)
		// pageno 2. list.get(10) ~ list.get(19)->(13-1)
		int start = (pageno-1)*pagesize;
		int end = start + pagesize -1;
		if(end>(list.size()-1))
			end = list.size()-1;
		List<Board> result = new ArrayList();
		for(Board board:list) {
			if(board.getBno()>=start && board.getBno()<=end)
				result.add(board);
		}
		return result;
	}
}












