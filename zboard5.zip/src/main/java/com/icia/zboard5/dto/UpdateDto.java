package com.icia.zboard5.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

// DTO : Data Transfer Object. 사용자와 입출력하는 클래스

@Data
@AllArgsConstructor
public class UpdateDto {
	private Integer bno;
	private String title;
	private String content;
}
