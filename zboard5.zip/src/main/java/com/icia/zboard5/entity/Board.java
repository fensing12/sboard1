package com.icia.zboard5.entity;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.icia.zboard5.dto.UpdateDto;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;

// Entity -> 자기 일은 자기가 한다 -> Domain 
@Getter
@EqualsAndHashCode
@ToString
@Builder
public class Board {
	private Integer bno;
	private String title;
	private String content;
	private String writer;
	private String attachment;
	@Builder.Default
	@JsonFormat(pattern="yyyy-MM-dd hh:mm:ss")
	private Date writeTime = new Date();
	@Builder.Default
	private Integer readCnt = 0;
	
	public void init(String uploadUrl, String name, int bno) {
		this.attachment = uploadUrl + name;
		this.bno = bno;
	}
	
	public void init(int bno) {
		this.bno = bno;
	}
	
	public void increaseReadCnt() {
		this.readCnt++;
	}
	
	public void update(UpdateDto dto) {
		this.title = dto.getTitle();
		this.content = dto.getContent();
	}
}


