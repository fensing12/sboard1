package com.icia.zboard5.entity;

import java.util.Date;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;

@Getter
@EqualsAndHashCode
@ToString
@Builder
public class Board {
	private Integer bno;
	private String title;
	private String content;
	private String writer;
	private String attachment;
	@Builder.Default
	private Date writeTime = new Date();
	@Builder.Default
	private Integer readCnt = 0;
	
	public void init(String uploadUrl, String name, int bno) {
		this.attachment = uploadUrl + name;
		this.bno = bno;
		
	}
	public void init(int bno) {
		this.bno = bno;
	}
}


