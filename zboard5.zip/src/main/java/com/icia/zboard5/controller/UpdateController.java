package com.icia.zboard5.controller;

import java.io.IOException;
import java.util.Optional;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.math.NumberUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.icia.zbaord5.service.BoardService;
import com.icia.zboard5.dto.UpdateDto;
import com.icia.zboard5.entity.Board;

@WebServlet("/board/update")
public class UpdateController extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("application/json;charset=utf-8");
		
		String str = request.getParameter("bno");
		Integer bno = NumberUtils.toInt(str, 0);
		String titile = request.getParameter("title");
		String content = request.getParameter("content");
		UpdateDto dto = new UpdateDto(bno, titile, content);
		
		BoardService service = BoardService.getInstance();
		Optional<Board> board = service.update(dto);
		if(board.isEmpty()) {
			response.setContentType("text/plain;charset=utf-8");
			response.setStatus(HttpServletResponse.SC_CONFLICT);
			response.getWriter().print("글을 찾을 수 없습니다");
		} else {
			response.setContentType("application/json;charset=utf-8");
			String json = new ObjectMapper().writeValueAsString(board.get());
			response.getWriter().print(json);
		}
	}
}







