package com.icia.zboard5.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.icia.zbaord5.service.BoardService;
import com.icia.zboard5.dto.WriteDto;
import com.icia.zboard5.entity.Board;

@MultipartConfig
@WebServlet("/board/new")
public class WriteController extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("application/json;charset=utf-8");
		String writer = request.getParameter("writer");
		String titile = request.getParameter("title");
		String content = request.getParameter("content");
		Part part = request.getPart("attachment");
		WriteDto dto = new WriteDto(titile, content, writer, part);
		
		BoardService service = BoardService.getInstance();
		Board board = service.write(dto);
		
		String json = new ObjectMapper().writeValueAsString(board);
		response.getWriter().print(json);
	}
}







