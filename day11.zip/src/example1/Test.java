package example1;

import java.util.Arrays;

public class Test {
	// 점수를 받아 "합격"/"불합격"을 리턴하는 함수
	String panjung(int score) {
		return score>=70? "합격" : "불합격";
	}
	
	// 숫자를 입력받아 제곱하는 함수 -> 오버로딩
	int square(int value) {
		return value*value;
	}
	double square(double value) {
		return value*value;
	}
	
	// 제곱미터를 평으로 바꾸는 함수
	// 21/3.3-> 6.36평
	double toPyung(int meter) {
		return meter/3.3;
	}
	 
	
	
	
	public static void main(String[] args) {
		int score = 80;
		
	}
}





















