package example1;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Test4 {
	public static void main(String[] args) {
		List<Integer> list = Arrays.asList(11,22,33,44,55);
		// JS 화살표함수의 경우 리턴이 있을 수도 없을 수도 있다
		// 자바의 forEach는 리턴이 없는 Lambda 함수가 필요하다 -> Consumer
		/*
		list.forEach((el)->{System.out.println(el);});
		list.forEach(el->{System.out.println(el);});
		list.forEach(el->System.out.println(el));
		*/

		// filter등의 메소드를 자바는 스트림이라고 한다
		// filter의 매개변수인 Predicate는 결과가 boolean인 람다
		list.stream().filter(i->i%2==0).forEach(a->System.out.println(a));
		list.stream().filter(i->{
			return i%2==0;
		}).forEach(a->System.out.println(a));
		
		// 자바는 List와 Stream이 다르다
		List<Integer> result 
		= list.stream().filter(a->a%2==0).collect(Collectors.toList());
		
		List<Board> boardList;
		for(int i=0; i<boardList.size(); i++) {
			if(boardList.get(i).getBno()==bno) 
				boardList.remove(i);
		}
		
	}
}






