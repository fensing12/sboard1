package example1;

public class Test2 {
	// 숫자를 입력받아 절대값을 출력하는 함수
	int abs(int value) {
		return value>0? value: -value;
	}
	
	// 숫자를 입력받아 홀수/짝수를 출력하는 함수
	String 홀짝판정(int value) {
		return value%2==0? "홀수":"짝수";
	}
	
	boolean isEven(int value) {
		return value%2==0? true:false;
	}
	
	enum 홀짝 {
		EVEN, ODD;
	}
	홀짝 홀짝판정2(int value) {
		return value%2==0? 홀짝.EVEN : 홀짝.ODD;
	}
	
	
	// 급여를 입력받아 500만원이상이면 "고급여", 미만이면 "저급여"라고 출력
	enum SalaryGrade {
		HIGH, LOW;
	}
	SalaryGrade getSalaryGrade(int salary) {
		return salary>=5000000? SalaryGrade.HIGH:SalaryGrade.LOW;
	}
	
	// 반지름을 입력받아 원의 면적을 출력
	double getAreaOfCircle(int radius) {
		return radius*3.14*3.14;
	}
	
	
	public static void main(String[] args) {
		int a = 10;
		// %2가 0이면 짝수, 1이면 홀수
		System.out.println(a%2==0);
	}
	
	
}
