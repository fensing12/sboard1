package example1;

public class Test3 {
	// 국어, 영어 성적으로 평균을 계산하는 함수
	double getAverage(int kor, int eng) {
		return (double)(kor+eng)/2;
	}
	
	// 국어, 영어 성적이 모두 70점이상이면 합격. 아니면 불합격을 출력하는 함수
	boolean isPass(int kor, int eng) {
		return kor>=70 && eng>=70;
	}
	
	// 너비와 높이를 입력받아 면적을 출력하는 함수
	int getArea(int height, int width) {
		return height * width;
	}
	
	// 급여와 소득세율을 매개변수로 받아 세금금액을 출력하는 함수
	// double getIncomeTax(int salary, double rate) : signature
	double getIncomeTax(int salary, double rate) {
		return salary * rate;
	}
	
}


