package com.icia.web.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.math.*;

import com.example.sample.service.*;

//url을 채워넣으시오
@WebServlet("")
public class DeleteController extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("application/json;charset=utf-8");
		
		// 사용자 입력값을 꺼낸 다음 글을 삭제하는 코드를 작성하시오
		 
		
		
		
		
		
		// 아래 if문에 글 삭제 성공/실패를 확인할 수 있는 조건을 작성하시오
		if(글 삭제에 실패한 경우) {
			response.setStatus(HttpServletResponse.SC_CONFLICT);
			response.getWriter().print("글을 찾을 수 없습니다");
		} else {
			response.getWriter().print(bno + "번 글을 삭제했습니다");
		}
	}
}
