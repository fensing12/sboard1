package com.icia.web.controller;

import java.io.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.databind.*;

//url을 채워넣으시오
@WebServlet("")
public class ReadController extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		
		// 사용자 입력값을 꺼내 글을 가져오는 코드를 작성하시오
		
	
		
		
		// 글 검색 성공 실패에 따른 출력 코드
		if(글 검색 실패) {
			response.setStatus(HttpServletResponse.SC_CONFLICT);
			response.getWriter().print("글을 찾을 수 없습니다");
		} else {
			response.setContentType("application/json;charset=utf-8");
			String json = new ObjectMapper().writeValueAsString();
			response.getWriter().print(json);
		}
	}
}
