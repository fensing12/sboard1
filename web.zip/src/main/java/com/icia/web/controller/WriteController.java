package com.icia.web.controller;

import java.io.*;

import javax.servlet.*;
import javax.servlet.annotation.*;
import javax.servlet.http.*;

import com.fasterxml.jackson.databind.*;

//url을 채워넣으시오
@WebServlet("")
public class WriteController extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("application/json;charset=utf-8");
		
		// request에서 사용자 입력값을 꺼내 WriteDto를 생성하시오
		
		
		
		
		// 서비스를 이용해 WriteDto를 저장하시오
		
		
		
		// 글목록을 아래 코드를 이용해 출력하시오
		
		PrintWriter out = response.getWriter();
		ObjectMapper objectMapper = new ObjectMapper();
		out.print(objectMapper.writeValueAsString());
	}
}
