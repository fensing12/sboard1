package com.icia.web.entity;

import java.util.*;

import com.example.sample.dto.*;
import com.fasterxml.jackson.annotation.*;

import lombok.*;

@Getter
@EqualsAndHashCode
@ToString
@Builder
public class Board {
	private Integer bno;
	private String title;
	
	// @JsonIgnore가 적용된 컬럼은 JSON으로 변환할 때 무시한다
	@JsonIgnore
	private String content;
	private String writer;
	@JsonIgnore
	private String attachment;
	
	@Builder.Default
	@JsonFormat(pattern="yyyy-MM-dd hh:mm:ss")
	private Date writeTime = new Date();
	
	@Builder.Default
	private Integer readCnt = 0;

	public void init(String uploadUrl, String name, int bno) {
		this.attachment = uploadUrl + name;
		this.bno = bno;
	}
	
	public void init(int bno) {
		this.bno = bno;
	}
	
	public void increaseReadCnt() {
		this.readCnt++;
	}
	
	public void update(UpdateDto dto) {
		this.title = dto.getTitle();
		this.content = dto.getContent();
	}
	
	public ReadDto toDto() {
		return new ReadDto(bno, title, content, writer, attachment, writeTime, readCnt);
	}
}
