package com.icia.web.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.*;

import com.example.sample.dto.*;
import com.example.sample.service.*;
import com.icia.web.entity.*;

public class BoardServiceTest {
	BoardService service = BoardService.getInstance();
	
	//@Test
	public void writeTest() {
		WriteDto dto = new WriteDto("새글", "새글", "spring", null);
		Board board = service.write(dto);
		// 글이 122개가 들어있다. 새로 작성한 글의 번호는 123
		assertEquals(123, board.getBno());
	}
	
	//@Test
	public void readTest() {
		// 글읽기 성공 테스트
		assertEquals(true, service.read(3).isPresent());
		// 글읽기 실패 테스트
		assertEquals(true, service.read(1111).isEmpty());
	}
		
	//@Test
	public void listTest() {
		assertEquals(122, service.list(2).getTotalcount());
	}
	
	//@Test
	public void updateTest() {
		UpdateDto dto = new UpdateDto(111, "변경했어요", "변경했지유");
		Board board = service.update(dto).get();
		assertEquals("변경했어요", board.getTitle());
	}
	
	@Test
	public void deleteTest() {
		service.delete(111);
		// 삭제했으니까 읽으면 글이 없다
		assertEquals(true, service.read(1111).isEmpty());
	}
}





