package com.icia.web.controller;

import java.io.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.math.*;

import com.example.sample.dto.*;
import com.example.sample.service.*;
import com.fasterxml.jackson.databind.*;

// url을 채워넣으시오
@WebServlet("/board/all")
public class ListController extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("application/json;charset=utf-8");
		
		// 사용자 입력값을 꺼내 글 목록을 가져오는 코드를 작성하시오
		String str = request.getParameter("pageno");
		int pageno = NumberUtils.toInt(str, 1);
		
		BoardService service = BoardService.getInstance();
		Page page = service.list(pageno);
		
		// 글목록을 아래 코드를 이용해 출력하시오
		PrintWriter out = response.getWriter();
		ObjectMapper objectMapper = new ObjectMapper();
		out.print(objectMapper.writeValueAsString(page));
	}
}
