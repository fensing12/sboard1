package com.icia.web.controller;

import java.io.*;
import java.util.*;

import javax.servlet.*;
import javax.servlet.annotation.*;
import javax.servlet.http.*;

import org.apache.commons.lang3.math.*;

import com.example.sample.dto.*;
import com.example.sample.service.*;
import com.fasterxml.jackson.databind.*;
import com.icia.web.entity.*;

//url을 채워넣으시오
@WebServlet("/board/update")
public class UpdateController extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		
		// request에서 사용자 입력값을 꺼내 UpdateDto를 생성하시오
		String str = request.getParameter("bno");
		Integer bno = NumberUtils.toInt(str, 0);
		String titile = request.getParameter("title");
		String content = request.getParameter("content");
		UpdateDto dto = new UpdateDto(bno, titile, content);
		
		// 서비스를 이용해 UpdateDto를 저장하시오
		BoardService service = BoardService.getInstance();
		Optional<Board> board = service.update(dto);

		if(board.isEmpty()) {
			response.setContentType("text/plain;charset=utf-8");
			response.setStatus(HttpServletResponse.SC_CONFLICT);
			response.getWriter().print("글을 찾을 수 없습니다");
		} else {
			response.setContentType("application/json;charset=utf-8");
			String json = new ObjectMapper().writeValueAsString(board.get());
			response.getWriter().print(json);
		}
	}
}
