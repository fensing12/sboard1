package com.example.sample.dto;

import java.util.*;

import com.icia.web.entity.*;

import lombok.*;

@Getter
@AllArgsConstructor
public class Page {
	private Integer pageno;	private Integer pagesize;
	private Integer totalcount;
	private List<Board> boardList;	
}
