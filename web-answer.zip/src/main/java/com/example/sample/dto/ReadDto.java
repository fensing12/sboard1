package com.example.sample.dto;

import java.util.*;

import com.fasterxml.jackson.annotation.*;

import lombok.*;

// 엔티티와 똑같은 Dto를 왜 만들었지?
// 글 목록 출력할 때 content에 @JsonIgnore 적용 
//   -> 글읽을 때는 내용을 출력해야 한다
// 즉 하나의 엔티티에 작업마다 요구사항이 다른 경우 Dto를 사용한다
@Getter
@AllArgsConstructor
public class ReadDto {
	private Integer bno;
	private String title;
	private String content;
	private String writer;
	private String attachment;
	@JsonFormat(pattern="yyyy-MM-dd hh:mm:ss")
	private Date writeTime;
	private Integer readCnt;
}
